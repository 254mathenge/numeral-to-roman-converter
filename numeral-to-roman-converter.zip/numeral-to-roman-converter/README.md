## A web app to convert arabic integers to roman numerals
### Intended to help Murang'a university Teach2Give trainees practice and learn more about the DOM
![Sample](./sample.png)